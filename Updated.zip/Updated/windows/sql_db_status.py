import pyodbc

def win_test_sql_db(job, host_credentials):
    try:
        if job.runs_on == 'localhost':
            connection_string = job.connection_string
        else:
            connection_string = job.connection_string.replace("localhost", job.runs_on)
        
        conn = pyodbc.connect(connection_string)
        cursor = conn.cursor()
        cursor.execute(job.query)
        result = cursor.fetchone()  # Assuming the query returns a single row
        
        if result:
            return f"sql_db,{job.runs_on},{job.name},PASS,{result[0]}"
        else:
            return f"sql_db,{job.runs_on},{job.name},FAIL,No data returned"

    except Exception as e:
        return f"sql_db,{job.runs_on},{job.name},FAIL,{e}"

    finally:
        if 'conn' in locals():
            conn.close()
