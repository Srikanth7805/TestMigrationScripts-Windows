import winrm
import requests
import subprocess

def win_test_agent_status(job, host_credentials):
    try:
        if job.config_type == 'api':
            response = requests.get(job.api_endpoint)
            if job.config_signature in response.text:
                return f"agents,{job.runs_on},{job.name},PASS,"
            else:
                return f"agents,{job.runs_on},{job.name},FAIL,Signature not found in API response"
        elif job.config_type == 'script':
            if job.runs_on == 'localhost':
                result = subprocess.run(job.test_command.split(), capture_output=True, text=True)
                if job.config_signature in result.stdout:
                    return f"agents,{job.runs_on},{job.name},PASS,"
                else:
                    return f"agents,{job.runs_on},{job.name},FAIL,Signature not found in script output"
            else:
                session = winrm.Session(f'http://{job.runs_on}:5985/wsman', auth=(host_credentials['username'], host_credentials['password']), transport='ntlm')
                response = session.run_cmd('powershell.exe', ['-Command', job.test_command])
                if job.config_signature in response.std_out.decode():
                    return f"agents,{job.runs_on},{job.name},PASS,"
                else:
                    return f"agents,{job.runs_on},{job.name},FAIL,Signature not found in script output"
    except Exception as e:
        return f"agents,{job.runs_on},{job.name},FAIL,{e}"
