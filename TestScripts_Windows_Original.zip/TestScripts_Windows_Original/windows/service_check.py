import winrm
import subprocess
import base64

def encode_powershell_command(command):
    """Encodes a PowerShell command to Base64 for WinRM execution."""
    command_bytes = command.encode('utf-16-le')
    return base64.b64encode(command_bytes).decode('ascii')

def win_test_service(job, host_credentials):
    try:
        if job.runs_on == 'localhost':
            PS_SERVICE_CHECK = f"""
            $service = Get-Service -Name {job.name} | Select-Object -ExpandProperty Status
            if ($service -eq '{job.expected_str_in_output}') {{
                'PASS'
            }} else {{
                'FAIL'
            }}
            """
            result = subprocess.run(["powershell", "-Command", PS_SERVICE_CHECK], capture_output=True, text=True, shell=True)
            if 'PASS' in result.stdout:
                return f"services,{job.runs_on},{job.name},PASS,"
            else:
                return f"services,{job.runs_on},{job.name},FAIL,{result.stderr}"
        else:
            session = winrm.Session(f'http://{job.runs_on}:5985/wsman', auth=(host_credentials['username'], host_credentials['password']), transport='credssp')
            PS_SERVICE_CHECK = f"""
            $service = Get-Service -Name {job.name} | Select-Object -ExpandProperty Status;
            if ($service -eq '{job.expected_str_in_output}') {{ 'PASS' }} else {{ 'FAIL' }}
            """
            encoded_command = encode_powershell_command(PS_SERVICE_CHECK)
            response = session.run_cmd('powershell.exe', ['-EncodedCommand', encoded_command])
            if 'PASS' in response.std_out.decode():
                return f"services,{job.runs_on},{job.name},PASS,"
            else:
                return f"services,{job.runs_on},{job.name},FAIL,{response.std_err.decode()}"
    except Exception as e:
        return f"services,{job.runs_on},{job.name},FAIL,{e}"
