import winrm
import subprocess
import base64

def encode_powershell_command(command):
    """Encodes a PowerShell command to Base64 for WinRM execution."""
    command_bytes = command.encode('utf-16-le')
    return base64.b64encode(command_bytes).decode('ascii')

def win_test_domain(job, host_credentials):
    try:
        if job.runs_on == 'localhost':
            PS_DOMAIN_CHECK = f"""
            $ProgressPreference = 'SilentlyContinue';
            try {{
                $domain = (Get-WmiObject Win32_ComputerSystem).Domain
                if ($domain -eq '{job.domain_name}') {{
                    'PASS'
                }} else {{
                    'FAIL'
                }}
            }} catch {{
                'FAIL'
            }}
            """
            result = subprocess.run(["powershell", "-Command", PS_DOMAIN_CHECK], capture_output=True, text=True, shell=True)
            if 'PASS' in result.stdout:
                return f"domain,{job.runs_on},{job.domain_name},PASS,"
            else:
                return f"domain,{job.runs_on},{job.domain_name},FAIL,{result.stderr}"
        else:
            session = winrm.Session(f'http://{job.runs_on}:5985/wsman', auth=(host_credentials['username'], host_credentials['password']), transport='credssp')
            PS_DOMAIN_CHECK = f"""
            $ProgressPreference = 'SilentlyContinue';
            try {{
                $domain = (Get-WmiObject Win32_ComputerSystem).Domain;
                if ($domain -eq '{job.domain_name}') {{ 'PASS' }} else {{ 'FAIL' }}
            }} catch {{
                'FAIL'
            }}
            """
            encoded_command = encode_powershell_command(PS_DOMAIN_CHECK)
            response = session.run_cmd('powershell.exe', ['-EncodedCommand', encoded_command])
            if 'PASS' in response.std_out.decode():
                return f"domain,{job.runs_on},{job.domain_name},PASS,"
            else:
                return f"domain,{job.runs_on},{job.domain_name},FAIL,{response.std_err.decode()}"
    except Exception as e:
        return f"domain,{job.runs_on},{job.domain_name},FAIL,{e}"
