import winrm
import requests
import subprocess

def win_test_agent_status(job, host_credentials):
    try:
        if job.runs_on == 'localhost':
            result = subprocess.run(["powershell", "-Command", job.test_command], capture_output=True, text=True)
            output = result.stdout.strip()  # Strip leading/trailing whitespace
        else:
            session = winrm.Session(f'http://{job.runs_on}:5985/wsman', auth=(host_credentials['username'], host_credentials['password']), transport='credssp')
            ps_script = f"{job.test_command}"
            response = session.run_ps(ps_script)
            output = response.std_out.decode().strip()  # Strip leading/trailing whitespace
        
        # Check if the output contains the expected signature
        if job.config_signature in output:
            return f"agents,{job.runs_on},{job.name},PASS,"
        else:
            return f"agents,{job.runs_on},{job.name},FAIL,Signature not found in script output"

    except Exception as e:
        return f"agents,{job.runs_on},{job.name},FAIL,{e}"

