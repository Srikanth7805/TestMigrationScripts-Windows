import argparse
import json
import threading
import queue
from types import SimpleNamespace
from getpass import getpass
from windows.connectivity import win_test_connectivity
from windows.domain_check import win_test_domain
from windows.service_check import win_test_service
from windows.agent_status import win_test_agent_status
from windows.sql_db_status import win_test_sql_db  # Import the SQL DB status module

# Queue for threading
q = queue.Queue()
lock = threading.Lock()
test_results = []
credentials = {}

def process_test_job(job):
    host_credentials = None
    if job.runs_on != 'localhost':
        host_credentials = credentials[job.runs_on]

    if job.category == "connectivity" and job.platform == "windows":
        result = win_test_connectivity(job, host_credentials)
        with lock:
            test_results.append(result)
    elif job.category == "domain" and job.platform == "windows":
        result = win_test_domain(job, host_credentials)
        with lock:
            test_results.append(result)
    elif job.category == "services" and job.platform == "windows":
        result = win_test_service(job, host_credentials)
        with lock:
            test_results.append(result)
    elif job.category == "agents" and job.platform == "windows":
        result = win_test_agent_status(job, host_credentials)
        with lock:
            test_results.append(result)
    elif job.category == "sql_db" and job.platform == "windows":
        result = win_test_sql_db(job, host_credentials)
        with lock:
            test_results.append(result)

def worker():
    while True:
        job = q.get()
        if job is None:
            break
        process_test_job(job)
        q.task_done()

def main():
    # Get the list of test jobs from a flattened input json
    test_jobs = []
    parser = argparse.ArgumentParser(description="Test Automation Script")
    parser.add_argument('test_plan_file', type=str, help='Path to the test plan JSON file')
    args = parser.parse_args()
    
    # Load test plan
    with open(args.test_plan_file, 'r') as f:
        input_json = json.load(f)

    # Check and load each category if it exists in the JSON
    for category in ["connectivity", "domain", "services", "agents", "sql_db"]:
        if category in input_json:
            for item in input_json[category]:
                flat_item = {"category": category}
                flat_item.update(item)
                test_jobs.append(SimpleNamespace(**flat_item))

    # Get Credentials
    target_runon_servers = []
    for job in test_jobs:
        if not job.runs_on in target_runon_servers:
            target_runon_servers.append(job.runs_on)
            if job.runs_on != 'localhost':
                username = input(f"Username for {job.runs_on}: ")
                password = getpass(f"Password for {job.runs_on}/{username}: ")
                credentials[job.runs_on] = {"username": username, "password": password}

    # Create 10 threads
    threads = []
    for _ in range(10):
        t = threading.Thread(target=worker)
        t.start()
        threads.append(t)

    # Process jobs
    for job in test_jobs:
        q.put(job)

    # Block until all tasks are done
    q.join()

    # Stop workers
    for _ in range(10):
        q.put(None)
    for t in threads:
        t.join()

    # Write output to CSV in the desired order
    with open('output.csv', 'w') as f:
        f.write("Category,RunsOn,Destination,Port/Domain/Service,Result,Error\n")
        for category in ["connectivity", "domain", "services", "agents", "sql_db"]:
            for result in test_results:
                if result.startswith(category):
                    f.write(result + "\n")

if __name__ == "__main__":
    main()
